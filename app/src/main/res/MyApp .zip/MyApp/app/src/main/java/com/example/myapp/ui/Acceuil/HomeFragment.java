package com.example.myapp.ui.Acceuil;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.myapp.R;

public class HomeFragment extends Fragment {
    private Button btn_sante ;
    private Button btn_bank ;
    private Button btn_poste ;
    private Button btn_sociaux ;



    public View onCreate (@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.activity_homedashbord, container, false);
        btn_sante = (Button) root.findViewById(R.id.btn_sante);
        btn_bank = (Button) root.findViewById(R.id.btn_bank);
        btn_sociaux = (Button) root.findViewById(R.id.btn_sociaux);
        btn_poste = (Button) root.findViewById(R.id.btn_post);

        btn_sante.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(0);
            }
        });
        btn_bank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(1);
            }
        });
        btn_sociaux.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(3);
            }
        });
        btn_poste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewActivity(2);
            }
        });
        return root;
    }
    public void openNewActivity(int id ){
        switch (id) {
            case  0 :
            Intent intent = new Intent(getActivity(), Sante.class);
            startActivity(intent); break;
            case  1 :
            intent = new Intent(getActivity(), BankActivity.class);
            startActivity(intent);

            break;
            case 2 :
            intent = new Intent(getActivity(), PostActivity.class);
            startActivity(intent); break;
            case 3 :

            intent = new Intent(getActivity(), servicespublics.class);
            startActivity(intent); break;
        }
    }
}
