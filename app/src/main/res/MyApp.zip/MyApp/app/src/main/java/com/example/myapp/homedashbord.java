package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class homedashbord extends AppCompatActivity {
    private Button btn_sante ;
    private Button btn_bank ;
    private Button btn_poste ;
    private Button btn_sociaux ;



        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homedashbord);
            btn_sante = (Button) findViewById(R.id.btn_sante);
            btn_bank = (Button) findViewById(R.id.btn_bank);
            btn_sociaux = (Button) findViewById(R.id.btn_sociaux);
            btn_poste = (Button) findViewById(R.id.btn_post);

            btn_sante.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openNewActivity();
                }
            });
            btn_bank.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openNewActivity();
                }
            });
            btn_sociaux.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openNewActivity();
                }
            });
            btn_poste.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openNewActivity();
                }
            });
        }
    public void openNewActivity(){
        Intent intent = new Intent(this, Sante.class);
        startActivity(intent);

        intent = new Intent(this, BankActivity.class);
         startActivity(intent);

        intent = new Intent(this, PostActivity.class);
        startActivity(intent);

        intent = new Intent(this, servicespublics.class);
        startActivity(intent);
}





}






